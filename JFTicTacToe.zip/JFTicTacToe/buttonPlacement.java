public class buttonPlacement {

    public static void place() {
        //Reihe 1
        Gui.btn[0].setBounds(175, 50, 150, 150);
        Gui.btn[1].setBounds(325, 50, 150, 150);
        Gui.btn[2].setBounds(475, 50, 150, 150);
        //Reihe 2
        Gui.btn[3].setBounds(175, 200, 150, 150);
        Gui.btn[4].setBounds(325, 200, 150, 150);
        Gui.btn[5].setBounds(475, 200, 150, 150);
        //Reihe 3
        Gui.btn[6].setBounds(175, 350, 150, 150);
        Gui.btn[7].setBounds(325, 350, 150, 150);
        Gui.btn[8].setBounds(475, 350, 150, 150);
    }
}
